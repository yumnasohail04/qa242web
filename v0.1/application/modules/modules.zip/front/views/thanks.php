<div class="veen">
      <div class="login-btn splits" style="vertical-align:none !important;text-align:left !important;">
		 <img src="<?php echo STATIC_ADMIN_IMAGE.'eq_smart_log_f1.png' ?>" style="width:40%; margin-left: 5%;">
      </div>
       <div class="rgstr-btn splits">
      </div>
      <div class="wrapper">
          <form id="login">
            <h1 style="color: #1e921e;"><i class="glyphicon glyphicon-ok-sign"></i>Thank You</h1>
            <p><?php echo $message; ?></p>
          </form>
          <div class="submit">
            <a href="<?php echo BASE_URL.'login/'.$supplier_id?>"><button class="dark" id="submit_btn">Back</button></a>
          </div>
      </div>
      
    </div>  
  </div>
<script type="text/javascript">

</script>
</body>
</html>