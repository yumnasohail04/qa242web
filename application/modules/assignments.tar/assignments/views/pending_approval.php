<!-- Page content-->
<div class="content-wrapper">
    <input type="hidden" id="assign_type" value="<?=$this->uri->segment(3);?>" />
    <h3><?php if($this->uri->segment(3) == 'active_checks') echo "Active"; elseif($this->uri->segment(3) == 'overdue_checks') echo "Overdue"; elseif($this->uri->segment(3) == 'pending_review') echo "Pending";  elseif($this->uri->segment(3) == 'pending_approval') echo "Pending Approval"; else echo ""; ?> Assignments</h3>
    <div class="container-fluid">
        <!-- START DATATABLE 1 -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                <label>From:</label>
                                    <div class='input-group datetimepicker2'>
                                        <input type='text' class="form-control" id="startdate" />
                                        <span class="input-group-addon">
                                            <span class="fa fa-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                 <label>To:</label>
                                    <div class='input-group datetimepicker2'>
                                    <input type='text' class="form-control" id="enddate" />
                                    <span class="input-group-addon">
                                        <span class="fa fa-calendar"></span>
                                    </span>
                                 </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <div class="form-group" style="margin-top: 33px;">
                                    <button type="button" class="btn btn-primary form-control filter_search">Search</button>
                                 </div>
                            </div>
                        </div>
                    <table id="datatable1" class="table table-striped table-hover table-body table-bordered">
                        <thead class="bg-th">
                        <tr class="bg-col">
                        <th class="text-center" style="width:120px;">Review Date <i class="fa fa-sort" style="font-size:13px;"></th>
                        <th class="text-center" style="width:120px;">Review Time <i class="fa fa-sort" style="font-size:13px;"></th>
                        <th class="text-center" style="width:200px;">Check Name <i class="fa fa-sort" style="font-size:13px;"></th>
                        <th class="text-center"style="width:200px;" >Reviewed By <i class="fa fa-sort" style="font-size:13px;"></th>
                        <th class="text-center" style="width:500px;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                                <?php
                                $i = 0;
                                if (isset($news)) {
                                    foreach ($news->result() as
                                            $new) {
                                        $i++;
                                        ?>
                                    <tr  id="Row_<?=$new->assign_id?>" class="odd gradeX "  >
                                        <td class="text-center"><?php echo date('m-d-Y',strtotime($new->review_datetime)); ?></td>
                                        <td class="text-center"><?php echo date('H:i:s',strtotime($new->review_datetime)); ?></td>
                                        <td class="text-center"><?php echo wordwrap( $new->checkname , 50 , "<br>\n");?></td>
                                        <td class="text-center">
                                            <?php
                                            if(isset($new->assign_id) && !empty($new->assign_id)) {
                                                $assignment_answer = Modules::run('api/_get_specific_table_with_pagination',array("assign_id"=>$new->assign_id),'assign_id desc',DEFAULT_OUTLET.'_assignments','review_user','1','1')->result_array();
                                                if(isset($assignment_answer[0]['review_user']) && !empty($assignment_answer[0]['review_user'])) {
                                                    $users = Modules::run('api/_get_specific_table_with_pagination',array("id"=>$assignment_answer[0]['review_user']),'id desc','users','user_name','1','1')->result_array();
                                                     $name=''; if(isset($users[0]['user_name']) && !empty($users[0]['user_name'])) $name= $users[0]['user_name']; $name=  Modules::run('api/string_length',$name,'8000',''); echo $name; 
                                                }
                                            }
                                            ?>
                                        </td>
                                        <td class="table_action text-center">
                                             <?php if($this->uri->segment(3) == 'pending_approval'){ ?>
                                            <?php $current_status= "";
                                            $outlet_status=array(""=>"Select Action","Completed"=>"Set To Completed");
                                            echo form_dropdown('order_status', $outlet_status, $current_status, 'class="add_on form-control select_action order_status" style="width:190px;" order_id="'.$new->assign_id.'"');?>
                                            <?}?>
                                        <a class="btn yellow c-btn view_details" rel="<?=$new->assign_id?>"><i class="fa fa-list"  title="See Detail"></i></a>
                                     
                                        </td>
                                    </tr>
                                    <?php } ?>    
                                <?php } ?>
                            </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    <!-- END DATATABLE 1 -->
    
    </div>
</div>    

<script type="text/javascript">
$(document).ready(function(){

    /*//////////////////////// code for detail //////////////////////////*/

            $(document).on("click", ".view_details", function(event){
            event.preventDefault();
            var id = $(this).attr('rel');
            //alert("<?=$this->uri->segment(3);?>"); return false;
              $.ajax({
                        type: 'POST',
                        url: "<?= ADMIN_BASE_URL?>assignments/pending_review_detail",
                        data: {'id': id,'function':'<?=$this->uri->segment(3);?>'},
                        async: false,
                        success: function(test_body) {
                        var test_desc = test_body;
                        //var test_body = '<ul class="list-group"><li class="list-group-item"><b>Description:</b> Akabir Abbasi Test</li></ul>';
                        $('#myModalLarge').modal('show')
                        //$("#myModal .modal-title").html(test_title);
                        $("#myModalLarge .modal-body").html(test_desc);
                        }
                    });
            });

    /*///////////////////////// end for code detail //////////////////////////////*/

          $(document).off('click', '.delete_record').on('click', '.delete_record', function(e){
                var id = $(this).attr('rel');
                e.preventDefault();
              swal({
                title : "Are you sure to delete the selected Post?",
                text : "You will not be able to recover this Post!",
                type : "warning",
                showCancelButton : true,
                confirmButtonColor : "#DD6B55",
                confirmButtonText : "Yes, delete it!",
                closeOnConfirm : false
              },
                function () {
                    
                       $.ajax({
                            type: 'POST',
                            url: "<?php ADMIN_BASE_URL?>post/delete",
                            data: {'id': id},
                            async: false,
                            success: function() {
                            location.reload();
                            }
                        });
                swal("Deleted!", "Post has been deleted.", "success");
              });

            });

       
    /*///////////////////////////////// START STATUS  ///////////////////////////////////*/
        
        $(document).off("click",".action_publish").on("click",".action_publish", function(event) {
            event.preventDefault();
            var id = $(this).attr('rel');
            var status = $(this).attr('status');
             $.ajax({
                type: 'POST',
                url: "<?= ADMIN_BASE_URL ?>post/change_status",
                data: {'id': id, 'status': status},
                async: false,
                success: function(result) {
                    if($('#'+id).hasClass('default')==true)
                    {
                        $('#'+id).addClass('green');
                        $('#'+id).removeClass('default');
                        $('#'+id).find('i.fa-long-arrow-down').removeClass('fa-long-arrow-down').addClass('fa-long-arrow-up');
                    }else{
                        $('#'+id).addClass('default');
                        $('#'+id).removeClass('green');
                        $('#'+id).find('i.fa-long-arrow-up').removeClass('fa-long-arrow-up').addClass('fa-long-arrow-down');
                    }
                    $("#listing").load('<?php ADMIN_BASE_URL?>post/manage');
                    toastr.success('Status Changed Successfully');
                }
            });
            if (status == 1) {
                $(this).removeClass('table_action_publish');
                $(this).addClass('table_action_unpublish');
                $(this).attr('title', 'Set Publish');
                $(this).attr('status', '0');
            } else {
                $(this).removeClass('table_action_unpublish');
                $(this).addClass('table_action_publish');
                $(this).attr('title', 'Set Un-Publish');
                $(this).attr('status', '1');
            }
           
        });
    /*///////////////////////////////// END STATUS  ///////////////////////////////////*/

});

$(document).ready(function() {
        $("#news_file").change(function() {
            var img = $(this).val();
            var replaced_val = img.replace("C:\\fakepath\\", '');
            $('#hdn_image').val(replaced_val);
        });
    });
</script>
<script>
$(document).ready(function() {
    $('.select_action').on('change', function() {
        var option=this.value;
        var assign_id = $(this).attr('order_id');
      if(option=='Check_again'){
             $.ajax({
                        type: 'POST',
                        url: "<?= ADMIN_BASE_URL?>assignments/check_again_for_assignment",
                        data: {'assign_id': assign_id},
                        async: false,
                        success: function(test_body) {
                             $('#myModalassignment').modal('show');
                             $("#myModalassignment .modal-body").html(test_body);
                          
                        }
                    });
      }else if(option=='Completed'){
           $.ajax({
                        type: 'POST',
                        url: "<?= ADMIN_BASE_URL?>assignments/pending_review_detail",
                        data: {'id': assign_id,'function':'<?=$this->uri->segment(3);?>',"datacomment":"ok"},
                        async: false,
                        success: function(test_body) {
                        var test_desc = test_body;
                       
                        $('#myModalLarge').modal('show')
                        $("#myModalLarge .modal-footer").html('<button type="button" data-dismiss="modal" class="btn btn-primary  pull-right">Cancel</button> <button type="button" class="btn btn-primary pull-right submit_check" > Approved</button>');
                        $("#myModalLarge .modal-body").html(test_desc);
                        }
                    });
      }
});
});
</script>

<script>
    $(document).ready(function() {
    $('.filter_search').on('click', function() {
        var startdate=$('#startdate').val();
        var enddate=$('#enddate').val();
        var assign_type = $('#assign_type').val();
        if(startdate=='' && enddate==''){
            toastr.success('Please Select Date Range');
           }else{
             $.ajax({
                        type: 'POST',
                        url: "<?= ADMIN_BASE_URL?>assignments/get_filter_result",
                        data: {'startdate': startdate,'enddate':enddate,'assign_type':assign_type},
                        async: false,
                        success: function(test_body) {
                            if(test_body!='')
                             $('#datatable1').html(test_body);
                             else
                              toastr.success('No result found b/w selected date');
                          
                        }
            });
           }    
});
});

   $(document).ready(function() {
    $('#checkagain').on('click', function() {
        var startdate=$('#startdate').val();
        var enddate=$('#enddate').val();
        var assign_type = $('#assign_type').val();
        if(startdate=='' && enddate==''){
            toastr.success('Please Select Date Range');
           }else{
             $.ajax({
                        type: 'POST',
                        url: "<?= ADMIN_BASE_URL?>assignments/get_filter_result",
                        data: {'startdate': startdate,'enddate':enddate,'assign_type':assign_type},
                        async: false,
                        success: function(test_body) {
                            if(test_body!='')
                             $('#datatable1').html(test_body);
                             else
                              toastr.success('No result found b/w selected date');
                          
                        }
            });
           }    
});
});
</script>
