<!-- <script src="<?php echo STATIC_ADMIN_JS?>moment/min/moment-with-locales.min.js"></script>
<script src="<?php echo STATIC_ADMIN_JS?>bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo STATIC_ADMIN_JS?>fullcalendar.min.js"></script>
<script>
      $('.datetimepicker2').datetimepicker({
      icons: {
          time: 'fa fa-clock-o',
          date: 'fa fa-calendar',
          up: 'fa fa-chevron-up',
          down: 'fa fa-chevron-down',
          previous: 'fa fa-chevron-left',
          next: 'fa fa-chevron-right',
          today: 'fa fa-crosshairs',
          clear: 'fa fa-trash'
        },
        //viewMode: 'years',
        format:'MM/DD/YYYY'
    });
</script>

</body>
</html> -->   
    <script src="<?php echo STATIC_ADMIN_JS?>fullcalendar.min.js"></script>
    <script data-cfasync="false" src="<?php echo STATIC_FRONT_JS?>email-decode.min.js"></script><script src="<?php echo STATIC_FRONT_JS?>bootstrap.min.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>page-transition.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>jquery.shuffle.min.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>masonry.pkgd.min.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>owl.carousel.min.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>jquery.magnific-popup.min.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>jquery.hoverdir.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>main.js"></script>
    <script src="<?php echo STATIC_FRONT_JS?>lmpixels-demo-panel.js"></script>
    <script src="<?php echo STATIC_ADMIN_JS?>sweetalert.min.js"></script>
    <!-- <script src="<?php echo STATIC_FRONT_JS?>validator.js"></script> -->



  </body>
</html>
