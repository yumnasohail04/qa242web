   <div class="veen">
      <div class="login-btn splits" style="vertical-align:none !important;text-align:left !important;">
		 <img src="<?php echo STATIC_ADMIN_IMAGE.'eq_smart_log_f1.png' ?>" style="width:40%; margin-left: 5%;">
      </div>
       <div class="rgstr-btn splits">
      </div>
      <div class="wrapper">
          <form id="login">
            <h1 style="color: #1e921e;"><i class="glyphicon glyphicon-ok-sign"></i>Finish</h1>
            <p><?php echo $detail['name']." Thankyou for Completing your Profile by providing your Documents." ?></p>
          </form>
      </div>
    </div>  
  </div>
<script type="text/javascript">

</script>
</body>
</html>